﻿using Microsoft.AspNetCore.Mvc;

namespace mvcProject1.Views.shared.Components
{
    public class LeftNavigation : ViewComponent
    {
        public IViewComponentResult Invoke()
        {
            var links = new List<NavigationLink>
        {
            new NavigationLink { Text = "Home", Url = "/" },
            new NavigationLink { Text = "Employees", Url = "/Employees" },
            new NavigationLink { Text = "Privacy", Url = "/Privacy" }
        };

            return View(links);
        }
    }

    public class NavigationLink
    {
        public string Text { get; set; }
        public string Url { get; set; }
    }
}

